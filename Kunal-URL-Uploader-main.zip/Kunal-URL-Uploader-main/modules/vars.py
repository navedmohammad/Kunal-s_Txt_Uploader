api_id = "27994649"
api_hash = "a667f9bf86b1e9af6ee9862fee3001e4"
bot_token = "6767726971:AAG0kQTgbAXaqyd0kd1_tR0vdiAO21J48eQ"
